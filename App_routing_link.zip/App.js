
import React,{Component} from "react";
function App(){
  return(
   <div>
     <h1>
       This is App !!
     </h1>
   </div>
  )
}

export default App;