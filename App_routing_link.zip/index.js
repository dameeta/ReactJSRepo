import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Router,  Routes, Route, Link } from "react-router-dom";
import App from "./App";
import Home from "./Home";

const routing=(
  <BrowserRouter>
  <div>
    <h1>Home</h1>
    <ul>
      <li>
        <Link to="/">Home</Link>
      </li>
    </ul>
  

<Routes>

<Route exact path="/" element={<App/>}/>

<Route path="/home" element={<Home/>}/>
</Routes>

</div>
</BrowserRouter>
)

ReactDOM.render(routing, document.getElementById("root"));